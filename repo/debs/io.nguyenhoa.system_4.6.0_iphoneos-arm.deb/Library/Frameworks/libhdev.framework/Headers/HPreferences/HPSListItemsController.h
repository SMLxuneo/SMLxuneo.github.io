#import <Preferences/PSListItemsController.h>
#import <Preferences/PSSpecifier.h>

#import "../HUtilities/HCommon.h"
#import "HPSRootListController.h"

@interface HPSListItemsController : PSListItemsController
@end
